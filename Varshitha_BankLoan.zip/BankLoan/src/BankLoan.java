import java.util.Scanner;
public class BankLoan {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        // Display the menu
        System.out.println("1\t State Bank India");
        System.out.println("2\t Kotak Mahindra Bank");
        System.out.println("3\t The Vishakhapatnam Cooperative Bank");
        System.out.println("4\t Bank of Baroda");

        System.out.println("Please enter your choice in number:");

        //Get user's choice
        int choice = in.nextInt();

        //Display the title of the chosen module
        switch (choice) {

            case 1:
                System.out.println("You have chosen SBI \n");
                System.out.println("Now choose the loan type \n");
                System.out.println("1.Personal Loan \n 2.Educational Loan");
                int SBI = in.nextInt();
                switch (SBI) {
                    case 1:
                        double p, tp, cal;
                        System.out.println("Enter the amount:");
                        Scanner scan = new Scanner(System.in);
                        p = scan.nextFloat();
                        System.out.println("Enter the Time Period:");
                        tp = scan.nextFloat();
                        scan.close();
                        float i = 0.014f;
                        cal = (p * i * Math.pow(1 + i, tp)) / (Math.pow(1 + i, tp) - 1);
                        System.out.println("The Interest is:" + cal);
                        System.out.println("In Time Period:" + tp);
                        break;

                    case 2:
                        double principle, timeperiod, calculator;
                        System.out.println("Enter the amount:");
                        Scanner sca = new Scanner(System.in);
                        principle = sca.nextFloat();
                        System.out.println("Enter the Time Period:");
                        timeperiod = sca.nextFloat();
                        sca.close();
                        float inte = 0.005f;
                        cal = (principle * inte * Math.pow(1 + inte, timeperiod)) / (Math.pow(1 + inte, timeperiod) - 1);
                        System.out.println("The Interest is:" + cal);
                        System.out.println("In Time Period:" + timeperiod);
                        break;
                }
                break;


            case 2:
                System.out.println("You have chosen KMB Bank");
                System.out.println("Now choose the loan type \n");
                System.out.println("1.Personal Loan \n 2.Educational Loan");
                int KMB = in.nextInt();
                switch (KMB) {
                    case 1:
                        double p, tp, cal;
                        System.out.println("Enter the amount:");
                        Scanner scan = new Scanner(System.in);
                        p = scan.nextFloat();
                        System.out.println("Enter the Time Period:");
                        tp = scan.nextFloat();
                        scan.close();
                        float interest = 0.0058f;
                        cal = (p * interest * Math.pow(1 + interest, tp)) / (Math.pow(1 + interest, tp) - 1);
                        System.out.println("The Interest is:" + cal);
                        System.out.println("In Time Period:" + tp);
                        break;

                    case 2:
                        double principle, timeperiod, calculator;
                        System.out.println("Enter the amount:");
                        Scanner sc = new Scanner(System.in);
                        principle = sc.nextFloat();
                        System.out.println("Enter the Time Period:");
                        timeperiod = sc.nextFloat();
                        sc.close();
                        float inte = 0.0066f;
                        cal = (principle * inte * Math.pow(1 + inte, timeperiod)) / (Math.pow(1 + inte, timeperiod) - 1);
                        System.out.println("The Interest is:" + cal);
                        System.out.println("In Time Period:" + timeperiod);
                        break;
                }
                break;


            case 3:
                System.out.println("You have chosen VCB Bank");
                System.out.println("Now choose the loan type \n");
                System.out.println("1.Personal Loan \n 2.Educational Loan");
                int VCB = in.nextInt();
                switch (VCB) {
                    case 1:
                        double p, tp, cal;
                        System.out.println("Enter the amount:");
                        Scanner scan = new Scanner(System.in);
                        p = scan.nextFloat();
                        System.out.println("Enter the Time Period:");
                        tp = scan.nextFloat();
                        scan.close();
                        float interest = 0.005f;
                        cal = (p * interest * Math.pow(1 + interest, tp)) / (Math.pow(1 + interest, tp) - 1);
                        System.out.println("The Interest is:" + cal);
                        System.out.println("In Time Period:" + tp);
                        break;

                    case 2:
                        double principle, timeperiod, calculator;
                        System.out.println("Enter the amount:");
                        Scanner s = new Scanner(System.in);
                        principle = s.nextFloat();
                        System.out.println("Enter the Time Period:");
                        timeperiod = s.nextFloat();
                        s.close();
                        float inte = 0.005f;
                        cal = (principle * inte * Math.pow(1 + inte, timeperiod)) / (Math.pow(1 + inte, timeperiod) - 1);
                        System.out.println("The Interest is:" + cal);
                        System.out.println("In Time Period:" + timeperiod);
                        break;
                }
                break;


            case 4:
                System.out.println("You have chosen BOB Bank");
                System.out.println("Now choose the loan type \n");
                System.out.println("1.Personal Loan \n 2.Educational Loan");
                int BOB = in.nextInt();
                switch (BOB) {
                    case 1:
                        double p, tp, cal;
                        System.out.println("Enter the amount:");
                        Scanner scan = new Scanner(System.in);
                        p = scan.nextFloat();
                        System.out.println("Enter the Time Period:");
                        tp = scan.nextFloat();
                        scan.close();
                        float interest = 0.0066f;
                        cal = (p * interest * Math.pow(1 + interest, tp)) / (Math.pow(1 + interest, tp) - 1);
                        System.out.println("The Interest is:" + cal);
                        System.out.println("In Time Period:" + tp);
                        break;

                    case 2:
                        double principle, timeperiod, calculator;
                        System.out.println("Enter the amount:");
                        Scanner a = new Scanner(System.in);
                        principle = a.nextFloat();
                        System.out.println("Enter the Time Period:");
                        timeperiod = a.nextFloat();
                        a.close();
                        float inte = 0.0014f;
                        cal = (principle * inte * Math.pow(1 + inte, timeperiod)) / (Math.pow(1 + inte, timeperiod) - 1);
                        System.out.println("The Interest is:" + cal);
                        System.out.println("In Time Period:" + timeperiod);
                        break;
                }
                break;
            default:
                System.out.println("Invalid choice");
        }
    }
}